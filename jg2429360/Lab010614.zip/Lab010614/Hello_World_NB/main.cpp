/* 
 * File:   main.cpp
 * Author: Jonathan Gaitan
 *
 * Created on January 6, 2014, 6:13 PM
  Our first program in Netbeans!
*/
//System Libraries
#include <iostream>

using namespace std;

 //Global Constants
  
 //Function Prototypes
 
 //Execution Begins Here!
int main(int argc, char** argv) {
  //print the string Hello World
    cout<<"Hello World"<<endl;
    return 0;
}

