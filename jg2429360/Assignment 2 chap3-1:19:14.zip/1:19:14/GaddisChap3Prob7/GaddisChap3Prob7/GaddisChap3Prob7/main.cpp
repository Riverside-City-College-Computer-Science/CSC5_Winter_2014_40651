//
//  main.cpp
//  GaddisChap3Prob7
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int rain1, rain2, rain3, avrg, rainAvrg;
    string month1, month2, month3;
    
    
    
    
    cout<<" First Month?"<<endl;
    cin>>month1;
    
    cout<<"how much did it rain"<<endl;
    cin>>rain1;
    
    cout<<" Second Month?"<<endl;
    cin>>month2;
    
    cout<<"how much did it rain"<<endl;
    cin>>rain2;
    
    cout<<" Third Month?"<<endl;
    cin>>month3;
    
    cout<<"how much did it rain"<<endl;
    cin>>rain3;
    
    avrg = (rain1)+(rain2)+(rain3);
    rainAvrg = avrg/3;
    
    
    cout<<"The average monthly rainfall for "<<month1<<", " << month2<< " and ";
    cout<<month3 << " is "<< rainAvrg<< "inches."<<endl;

    return 0;
}

