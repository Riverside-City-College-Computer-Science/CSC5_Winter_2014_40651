//
//  main.cpp
//  GaddisChap3Prob6
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[])
{
    int test1, test2, test3, test4, test5, avrg;
    
    
    
    
    cout<<"What is your first test score?";
    cin>>test1;
    
    cout<<"What is your second test score?";
    cin>>test2;
    
    cout<<"What is your third test score?";
    cin>>test3;
    
    cout<<"What is your fourth test score?";
    cin>>test4;
    
    cout<<"What is your fifth test score?";
    cin>>test5;
    
    avrg = (test1)+(test2)+(test3)+(test4)+(test5);
    
    
    
    cout<<"The average score is " <<avrg/5<<endl;
    
    
    return 0;
}

