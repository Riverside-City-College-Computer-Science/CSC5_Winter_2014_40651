//
//  main.cpp
//  GaddisChap3Prob15
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    
    float propertyValue, assessmentValue, propertyTax, quaterlyPayment;
    
    
    cout<<"Senior citizens homeowner exemption"<<endl;
    cout<<"Enter the actual value of the property:"<<endl;
    cin>>propertyValue;
    
    assessmentValue = propertyValue * 0.60;
    
    propertyTax = ((assessmentValue - 5000) / 100) * 2.64;  //don't forget to include the 5k senior exemption
    
    quaterlyPayment = propertyTax/4;
    
    
    cout<<setprecision(2) << fixed;
    
    cout<<"You will pay: $" << propertyTax << " annual property tax "<<endl;
    
    cout<<"Your quarterly payments will be: $" << quaterlyPayment <<endl;
    
    
    return 0;
    
}

