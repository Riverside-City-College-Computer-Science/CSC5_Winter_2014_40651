//
//  main.cpp
//  GaddisChap3Prob9
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int Widgets=9.2, Pallet, Swidgets;
    cout<<"How much does a pallet weigh?"<<endl;
    cin>>Pallet;
    //compute the weight
    Swidgets= Pallet * Widgets;
    cout<<"The total weight of the pallet stacked with widgets is "<<Swidgets<<endl;

    return 0;
}

