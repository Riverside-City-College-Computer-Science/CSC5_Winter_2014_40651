//
//  main.cpp
//  GaddisChap3Prob2
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    float a = 15.00, b  = 12.00, c = 9.00;
   float aAmount, bAmount, sAmount;

    float income = aAmount*a + bAmount*b + sAmount*c;
    
    
    cout<<"a tickets";
    cin>>aAmount;
    
    cout<<"b tickets";
    cin>>bAmount;
    
    cout<<"c tickets";
    cin>>sAmount;
    
    
    
    cout << income << endl;
   // cout << setprecision(2) << income << endl;
    
    

    return 0;
}

