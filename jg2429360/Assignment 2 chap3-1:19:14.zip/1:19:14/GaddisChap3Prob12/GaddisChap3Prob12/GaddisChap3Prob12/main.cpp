//
//  main.cpp
//  GaddisChap3Prob12
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    
    const float YEN_PER_DOLLAR = 83.14;
    
    const float EUROS_PER_DOLLAR = 0.7337;
    
    float dollars, yen, euros;
    
    cout << setprecision(2) << fixed;
    
    cout << "Enter dollar amount: "<<endl;
    
    cin >> dollars;
    
    yen = dollars * YEN_PER_DOLLAR;
    
    euros = dollars * EUROS_PER_DOLLAR;
    
    cout<<"Conversion"<<endl;
    
    cout<< "$" << dollars << " = " << yen << " Yen "<<endl;
    
    cout<< "$" << dollars << " = " << euros << " Euros "<<endl;
    
    return 0;
}

