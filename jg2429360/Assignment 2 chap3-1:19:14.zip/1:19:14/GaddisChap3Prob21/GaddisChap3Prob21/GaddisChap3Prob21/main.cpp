//
//  main.cpp
//  GaddisChap3Prob21
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

int main() {
    float angle, sine, cosine, tangent;
    
    cout<<"Angle Calculator"<<endl;
    
    cout<<"Enter an angle (in radians): "<<endl;
    cin>>angle;
    
    sine = sin(angle);
    cosine = cos(angle);
    tangent = tan(angle);
    
    cout<<setprecision(4)<< fixed<<endl;
    
    cout<<"The sine is: "<< sine <<endl;
    
    cout<<"The cosine is: "<< cosine <<endl;
    
    cout<<"The tangent is: "<< tangent << "\n\n"<<endl;
    
    return 0;
    
}
