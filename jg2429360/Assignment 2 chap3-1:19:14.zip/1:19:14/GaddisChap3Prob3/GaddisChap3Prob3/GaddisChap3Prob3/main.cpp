//
//  main.cpp
//  GaddisChap3Prob3
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[])
{
    int rent, utilities, phone, cable, Tpay;
    
    //Monthly rent
    cout<<"how much rent is paid monthly ?"<<endl;
    cin>>rent;
    
    //monthly utilities
    cout<<"monthly utilities rent ?"<<endl;
    cin>>utilities;
    
    //monthly phones
    cout<<"monthly phone bill ?"<<endl;
    cin>>phone;
    
    //monthly cable
    cout<<"monthly cable bill ?"<<endl;
    cin>>cable;
    
    Tpay=rent + utilities + phone + cable;
    
    cout<<"The monthly payment is"<<Tpay<<endl;
    return 0;
}

