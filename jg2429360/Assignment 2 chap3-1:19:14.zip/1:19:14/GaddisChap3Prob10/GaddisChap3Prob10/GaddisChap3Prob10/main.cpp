//
//  main.cpp
//  GaddisChap3Prob10
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int Amcookies=4, SCals=75, tCals = Amcookies * SCals;
    cout<<"How many cookies did you eat?"<<endl;
    cin>>Amcookies;
    //compute and display the number of tCals consumed
    tCals=Amcookies * SCals ;
    cout<<"The total calories consumed. "<<tCals<<endl;

    return 0;
}

