//
//  main.cpp
//  GaddisChap3Prob1
//
//  Created by Jonathan Gaitan on 1/18/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int Fuel, Miles, Distance;
    
    cout<<"How many gallons of gas does your car hold?"<<endl;
    cin>>Fuel;
    cout<<"How many miles can be driven with a full tank?"<<endl;
    cin>>Distance;
    
    //compute and display the Gas and tMiles
    
    Miles=Distance / Fuel ;
    cout<<"The number of Miles per gallon is "<<Miles<<endl;
    return 0;
}

