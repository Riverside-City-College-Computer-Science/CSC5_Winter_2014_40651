/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 15, 2014, 7:14 PM
 */

#include <iomanip>
#include <iostream>
using namespace std;

//Global Constant
const short CNV_PERC=100;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //delcare variables
    float presVal, fchrVal, iRate;
    short nPeriods;
    //Prompt for inputs
    cout<<"what is your present value $'s"<<endl;
    cin>>presVal;
    
    cout<<"what is your inf/inv/roi %"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    
    cout<<"How many compounding periods? (yrs)"<<endl;
    cin>>nPeriods;
    cout<<"year future value"<<endl;
    cout<<setprecision(2)<<fixed<<showpoint;
    //Loop to dtermine the future Value
    //Print every year
        fchrVal=presVal;//at time = 0
        int year=1;
        while(year<=nPeriods){
        fchrVal*=(1+iRate);
        cout<<setw(4)<<year;
        cout<<setw(11)<<fchrVal<<endl;
        year++;
        
        
    }
    //Exit stage right
    return 0;
}

