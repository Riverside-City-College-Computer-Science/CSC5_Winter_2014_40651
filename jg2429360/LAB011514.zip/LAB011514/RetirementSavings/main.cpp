/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 15, 2014, 8:35 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;


//Global Constants
const unsigned char CNV_PERC=100;

//Funtion Prototypes

//
/*
 * 
 */
int main(int argc, char** argv) {
    //Declare variables
    float retSave=0,salary,yrDep,iRate;
    //input some values
    cout<<"what salary do you make$'s"<<endl;
    cin>>salary;
    cout<<"What percentage of your salary would "
        <<"you put into retirement? %"<<endl;
    cin>>yrDep;
    yrDep*=(salary/CNV_PERC);
    cout<<"What municipal bond rate will you use %"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    //Heading
    cout<<setprecision(2)<<fixed<<showpoint;
    cout<<endl;
    cout<<"Income in retirement >= $"<<salary<<endl;
    cout<<"Municipal Bond rate ="<<iRate<<endl;
    cout<<"Yearly Deposit = $"<<yrDep<<endl;
    cout<<"Required Saving to Retire = $"<<salary/iRate<<endl;
    cout<<"Year Retirement Savings"<<endl;
    //Loop and print as you go to watch the savings grow
    int year=0;
    do{
        retSave*=(1+iRate);
        retSave+=yrDep;
        year++;
        cout<<setw(4)<<year;
        cout<<setw(15)<<retSave<<endl;
    }while(retSave<salary/iRate);
    //Exit Stage Right
    return 0;
}
