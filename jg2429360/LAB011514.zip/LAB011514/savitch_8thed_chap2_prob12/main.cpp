/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 15, 2014, 7:53 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

