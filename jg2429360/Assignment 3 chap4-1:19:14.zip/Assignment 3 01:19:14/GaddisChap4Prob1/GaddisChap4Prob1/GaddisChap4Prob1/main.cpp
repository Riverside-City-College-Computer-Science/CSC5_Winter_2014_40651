//
//  main.cpp
//  GaddisChap4Prob1
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    
    //Declare 2 variables
    float num1, num2;
    
    //ask user to enter a number
    cout<<"Enter 1st number "<<endl;
    cin>>num1;
    
    cout<<"Enter 2nd number "<<endl;
    cin>>num2;
    
    if(num1 > num2)
        cout<<("nThe 1st number is smaller than 2nd number. ")<<endl;
    
    else if(num1 < num2)
        cout<<("nThe 1st number is smaller than 2nd number." )<<endl;
    
    else cout<<("nThe 1st number is equal to the 2nd number,")<<endl;
    
    
    return 0;
}
