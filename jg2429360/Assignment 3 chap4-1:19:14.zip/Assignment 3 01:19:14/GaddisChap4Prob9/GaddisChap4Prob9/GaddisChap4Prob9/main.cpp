//
//  main.cpp
//  GaddisChap4Prob9
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;

int main ()
{
    int numSold;
    double pPrice, //purchase price per unit
    totalDue;
    const short PRICE = 99;
    bool flag = false;
    
    cout << "How many units sold? ";
    cin >> numSold;
    
    if (numSold <= 0)
        flag = true;
    else if (numSold < 10)
        pPrice = numSold * PRICE;
    else if (numSold < 20)
        pPrice = 0.8 * numSold * PRICE;
    else if (numSold < 50)
        pPrice = 0.7 * numSold * PRICE;
    else if (numSold < 100)
        pPrice = 0.6 * numSold * PRICE;
    else //further if for 100 or greater not needed
        pPrice = 0.5 * numSold * PRICE;
    
    totalDue = numSold * pPrice;
    
    if (flag)
    {
        cout << "Invalid entry, run the program again.\n";
        return 0; //ends the program prematurely if flag is true
    }
    
    cout << fixed << setprecision(2);
    cout << "\nUnits Sold:" << setw(49) << numSold <<endl;
    cout << "Purchase Price per Unit:" << setw(26) << "$" << setw(10) << pPrice << endl;
    cout << "Balance Due:" << setw(38) << "$" << setw (10) << totalDue << endl;
    return 0;
}