//
//  main.cpp
//  GaddisChap4Prob14
//
//  Created by Jonathan Gaitan on 1/19/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include <iostream>
using namespace std;

int main()
{
    int weight;
    float height,BMI;
    
    cout<<"Please enter your weight in pounds: ";
    cin>>weight;
    cout<<"\nPlease enter your height in inches: ";
    cin>>height;
    
    BMI =weight*703/(height*height);
    cout<<"\nYour body mass Index is: "<<BMI;
    
    if (BMI>25)
        cout<<"\n\nYou are somewhat overweight.";
    else if (BMI<18.5)
        cout<<"\n\nYou are somewhat underweight.";
    else if (BMI>18.5 && BMI <25)
        cout<<"\n\nCongratulations! You are within a healthy weight range.";
    
    cin.get ();
    cin.get ();
    return 0;
}
