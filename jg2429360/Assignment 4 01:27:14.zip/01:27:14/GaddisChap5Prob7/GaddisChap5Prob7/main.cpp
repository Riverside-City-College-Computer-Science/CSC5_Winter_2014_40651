//
//  main.cpp
//  GaddisChap5Prob7
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int days;
    
    cout<<"Enter The number of days you have worked this month:"<<endl;
    cin>>days;
    
    if(days < 1 || days > 31)
    { cout<<"Only enter a number between 1 and 31"<<endl;
        return 0;}
    
    int num = 1;
    for(int i = 1; i < days; i++){
        num = num * 2;
    }
    
    
    cout << "Number of days: "<<days<<endl<<"Number pennies paid per day: "<<num;
    cout << " \n";
    
    char wait; 
    cin>>wait; 
    
    return 0; 
}
