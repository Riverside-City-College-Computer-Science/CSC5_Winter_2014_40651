//
//  main.cpp
//  GaddisChap5Prob2
//
//  Created by Jonathan Gaitan on 1/24/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include <iostream>
using namespace std;

int main() {
    int positiveInteger;
    int startingNumber = 1;
    
    cout << "Please input an interger up to 100." << endl;
    cin >> positiveInteger;
    
    int result = 0;
    for (int i=startingNumber; i <= positiveInteger; i++)
    {
        result += i;
        cout << result;
    }
    
    cout << result;
    
    return 0;
    
}
