//
//  main.cpp
//  GaddisChap5Prob1
//
//  Created by Jonathan Gaitan on 1/27/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//


#include <cstdlib>
#include<iostream>

using namespace std;

int main()
{
    
    
    for (int i = 0; i <= 127; ++i)
    {
        cout << char(i) << " "; }
    
    for(int j = 1; j <= 16; j++){
        //cout<<endl; }
        
        
        cout<<endl;
    }
    return 0;
}
