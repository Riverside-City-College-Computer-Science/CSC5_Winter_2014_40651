//
//  main.cpp
//  GaddisChap5Prob3
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <iomanip>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    
	int speed, hours;
    cout << "What is the speed of the vehicle in MPH" << endl;
    cin >> speed;
	
	cout << "How many hours has it traveled" << endl;
	cin >> hours;
	
	cout << "Hours   Distance" << endl;
    
	for(int i = 1; i <= hours; i++)
        cout << i << "\t" << speed*i << endl;
	return 0;
}     

