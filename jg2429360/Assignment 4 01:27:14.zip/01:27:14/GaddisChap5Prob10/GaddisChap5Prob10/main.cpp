//
//  main.cpp
//  GaddisChap5Prob10
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <cstdlib>
#include<ctime>
using namespace std;

int main()
{
    
    int number;
    int randomNum;
    bool tryAgain= true;
    char reply;
    int guess;
    
    
    cout <<"Want to play a game?"<<endl;
    cout <<"Try and guess the number I am thinking of"<<endl;
    cout <<"and you will win."<<endl;
    
    while (tryAgain)
    {
        
        srand(time(0));
        randomNum = rand() % 100 + 1;
        
        cout <<"I'm thinking of a number between 1 and 100."<<endl;
        
        
        cout << "Try and guess my number: "<<endl;
        cin>>number;
        
        for (int played = 1; played == (number!= randomNum) ; played++){
            
            while (number!= randomNum){
                
                if (number < randomNum){
                    cout << "Your guess is too low...try again: "<<endl;
                    cin>>number;}
                
                if (number > randomNum){
                    
                    cout << "Your guess is too high...try again: "<<endl;
                    cin>>number; }
            }
            if (number == randomNum)
            {
                cout << "Congratulations you have won."<<endl;
                
                cout << "You made "<<played<<" failed attempts."<<endl;}
            
        } 
        cout<<"Dare to try again? Enter y or n: "<<endl;
        cin>>reply;
        
        if(reply!='y')
        {
            tryAgain=false;
            cout<<"Quitter."<<endl; } 
    }
    
    return 0;
}