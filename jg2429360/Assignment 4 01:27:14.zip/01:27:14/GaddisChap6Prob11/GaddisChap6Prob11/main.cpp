//
//  main.cpp
//  GaddisChap6Prob11
//
//  Created by Jonathan Gaitan on 1/27/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int    NS;   // Number of shares
    float SP;   // Selling Price
    float SC;   // Sales commission paid
    float PP;   // Purchase Price
    float PC;   // Purchase commission paid
    
    
    float profit (int,float,float,float,float);
    void warning();
    
    cout << "You are selling stock.\n";
    
    // Input Number of shares
    cout << "How many shares are you selling?\n";
    cin  >> NS;
    while (NS < 1){
        cout << "You must sell at least one share.\n";
        cout << "How many shares are you selling?\n";
        cin  >> NS; }
    
    // Input Sales Price
    cout << "How much are you selling the stock for?\n";
    cin >> SP;
    while (SP <= 0.0){
        warning();
        cout << "How much are you selling the stock for?\n";
        cin  >> SP; }
    
    // Input Sales commission
    cout << "How much must you pay the broker?\n";
    cin >> SC;
    while (SC <= 0.0){
        warning();
        cout << "How much must you pay the broker?\n";
        cin  >> SC; }
    
    // Input Purchase price
    cout << "How much did you initially buy the share for?\n";
    cin >> PP;
    while (PP <= 0.0){
        warning();
        cout << "How much did you initially buy the share for?\n";
        cin  >> PP; }
    
    // Input Purchase commission
    cout << "How much did you initially pay the broker?\n";
    cin >> PC;
    while (PC <= 0.0){
        warning();
        cout << "How much did you initially pay the broker?\n";
        cin  >> PC; }
    
    cout << "Total profit is " << profit(NS,SP,SC,PP,PC);
    
    return 0;
    
}

float profit(int NS, float SP, float SC, float PP, float PC)
{
    float result;
    
    result = (((float)NS * SP)-SC)-(((float)NS * PP) + PC);
    return result;
}

void warning()
{
    cout << "Amount must be greater than 0.00 USD.\n";
}
