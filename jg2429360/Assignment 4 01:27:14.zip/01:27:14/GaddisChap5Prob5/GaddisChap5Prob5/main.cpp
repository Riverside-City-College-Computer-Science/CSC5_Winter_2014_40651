//
//  main.cpp
//  GaddisChap5Prob5
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <iomanip>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    
    float mph, kph = 60, d = 0.0, d2 = 0.0;
    
    float conversion_rate = 0.6214;
    
    // Tells the user what the program is going to do.
    cout << "   KPH          MPH"<<endl;
    
    
    
    // produce a listing for each hour.
    
    mph = kph *.6214;
    
    for (d = 60, d2 = mph;d <=130; d +=5, d2 +=5)
        
        cout << fixed <<setw(10) << setprecision(3) << d << " " << fixed << setw(12)
        << setprecision(3) << d2 << endl; 
    
    return 0;
    
}

