//
//  main.cpp
//  GaddisChap5Prob6
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iomanip>
#include <iostream>
using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    
    int num;
    // maximum value to display
    int mx = 25;
    float milli = 3.1;
    
    // Explain the display program is showing.
    
    cout << "The ocean is rising 1.5 millimeter per year for the next 25 years."
    <<endl;
    
    cout << " Years              millimeters"<<endl;
    
    for (num=1;num <=25;num +=1)
        
        cout << num << "\t\t" << setprecision(2) << setw(6) << right << (num * milli)<< endl;
    
    
    return 0;
    
}
