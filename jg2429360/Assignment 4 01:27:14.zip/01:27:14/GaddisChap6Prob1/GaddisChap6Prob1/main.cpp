//
//  main.cpp
//  GaddisChap6Prob1
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include<iostream>
#include<iomanip>
using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    
    float calculatedRetail (double cost, double markUp);
    //variables
    float retail, cost, markUp;
    //output
    cout<<fixed<<showpoint<<setprecision(2);
    
    cout<<"Enter the wholesale cost for the item: $";
    cin >>cost;
    //validate the cost price
    while (cost<0)
    {
        cout<<"Please enter a positive number. $"<<endl;
        cin >>cost;
    }
    
    cout<<"Now please enter its markup percentage: ";
    cin >>markUp;
    //validate the markup percentage
    while (markUp<0)
    {
        cout<<"Please enter a positive number for markup: ";
        cin >>markUp;
    }
    //convert markup percentage to two decimal point
    markUp = (markUp/100);
    
    cout<<"The retail price for the item is: "<<endl;
    cout<<"$ " <<calculatedRetail(cost, markUp)<<endl;
    
    return 0;
}
float calculatedRetail (float cost, float markUp)
{
    return (cost*markUp)+cost;
}


