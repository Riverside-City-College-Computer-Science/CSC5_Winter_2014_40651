//
//  main.cpp
//  GaddisChap5Prob12
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#define EXIT -99
#define CONTINUE 1
using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int smallest, largest, current;
	while (true) {
	loop:
		cout << "Number: ";
		cin >> current;
		if (current == EXIT) break;
		smallest <= current;
		largest >= current;
	}
	cout << "Smallest: " << smallest << endl;
	cout << "Largest: " << largest << endl;
	cout << "1 to continue, anything else to bugger off" << endl;
	cin >> current;
	if (current == CONTINUE) goto loop;
	return(0);
}


