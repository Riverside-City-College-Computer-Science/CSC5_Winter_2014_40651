//
//  main.cpp
//  GaddisChap6Prob2
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int toCelsius(int fahr);
    
    cout << "Farenheit\tCelsius\n";
    for(int i = 0; i <= 20; i++)
    {
        cout << i << "\t\t" << toCelsius(i) << endl; }
    return 0;
}

int toCelsius(int fahr)
{
    return(int) ((fahr - 32.0) * (5.0/9.0));
}

