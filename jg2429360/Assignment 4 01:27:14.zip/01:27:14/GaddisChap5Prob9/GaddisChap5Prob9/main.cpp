//
//  main.cpp
//  GaddisChap5Prob9
//
//  Created by Jonathan Gaitan on 1/27/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <iomanip>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int Yrs;
    float Char=2500;
    
    cout<<"The projected rates for the next couple years"<<endl;
    
    cout<<"Years          Char"<<endl;
    
    for(Yrs=1; Yrs <=6; Yrs +=1)
        cout<< Yrs<<"\t\t"<<setprecision (6)<<setw(4)<< right <<( Yrs * Char)<<endl;
    
    return 0;
}

