//
//  main.cpp
//  GaddisChap5Prob8
//
//  Created by Jonathan Gaitan on 1/26/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
#include <iomanip>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    int Cals, Mins;
    float  Bcals=3.9;
    
    cout<<"The numbers of Cals burned over 30 mins"<<endl;
    
    cout<<"Mins       Cals"<<endl;
    
    for (Mins=5;Mins <=30;Mins +=5)
        
        
        cout << Mins << "\t\t" << setprecision (6) <<setw (4)<<  (Mins * Bcals) <<endl;
    
    return 0;
}

