//
//  main.cpp
//  GaddisChap6Prob3
//
//  Created by Jonathan Gaitan on 1/27/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

# include <iostream>
# include <cmath>
# include <string>

using namespace std;

/*
 *
 */
int main(int argc, char** argv) {
    void fallingDistance2(float &, float);
    float fallingDistance1(float);
    const float g = 9.8;
    float t;
    float d;
    cout<<"calculated by pass by values.\n";
    cout<<"Time \t\t Distance"<<endl;
    cout<<"-------------------"<<endl;
    for (t=1;t<=10;t++)
    {
        cout<<t<<"\t\t"<<fallingDistance1(t)<<endl;
    }
    
    
    cout<<"calculated by reference values."<<endl;
    cout<<"Time \t\t Distance"<<endl;
    cout<<"-------------------"<<endl;
    for (t=1;t<=10;t++)
    {
        fallingDistance2(d, t);
        cout<<t<<"\t\t"<<d<<endl;
    }
    
    
    return 0;
}


float fallingDistance1(float t)
{
    return 0.5*9.8*t*t;
}

void fallingDistance2(float &refd, float t)
{
    refd=0.5*9.8*t*t;
}




