/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 13, 2014, 8:53 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare out Variables
    short score;
    char grade;
    //Input the score
    cout<<"What is your test/project/hmwk score?"<<endl;
    cin>>score;
    
    //Process the grade
    if(score>=90)      grade='A';
    if(score>=80&&score<90)grade='B';
    if(score>=70&&score<80)grade='C';
    if(score>=60&&score<70)grade='D';
    if(score<60)          grade='F';
    //Output the grade
    cout<<"Your grade is a "<<grade<<endl;
    //Exit stage right

    return 0;
}