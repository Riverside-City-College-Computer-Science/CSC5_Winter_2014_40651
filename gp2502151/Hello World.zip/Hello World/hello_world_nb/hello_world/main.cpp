/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 6, 2014, 6:15 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

