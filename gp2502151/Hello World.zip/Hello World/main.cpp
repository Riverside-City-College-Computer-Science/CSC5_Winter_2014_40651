gilvero pascual january 
,#include <cstdlib>
#include <iostream

using namespace std;

int main(int argc, char *argv[])
{
    c.output.pint."ello wol";
    system("PAUSE");
    return EXIT_SUCCESS;
}
