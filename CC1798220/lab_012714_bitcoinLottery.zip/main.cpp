/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Choose the student who wins the lottery
 *
 * Created on January 27, 2014, 7:50 PM
 */

#include <cstdlib>
#include <fstream>
#include <ctime>
#include <iostream>

using namespace std;

//Global Constants

//Function prototypes
int random(int);
int winner(int [],int);
int read(char [],int[]);
void write(int [],int);

int main(int argc, char** argv) {
    //declare variables and initialize
    char fName[]="./student_id.dat";
    const int size=35;
    int sId[size];
    srand(static_cast<unsigned int>(time(0)));
    //read the file name
    int actSize=read(fName,sId);
    write(sId,actSize);
    //choose the winner
    cout<<endl<<"the winner is ->"
            <<winner(sId,actSize)<<endl;
    
    return 0;
}
int winner(int sId[],int n){
    return sId[random(n)];
}
void write(int sId[],int size){
    cout<<endl;
    cout<<"The contents of the file is"<<endl;
    for(int name=0;name<size;name++){
        cout<<name<<"->"<<sId[name]<<endl;
        
    }
    cout<<endl;
}
int read(char fName[],int sId[]){

    //declare variables
    int cnt=0;
    ifstream input;
    input.open(fName);
    while(input){
        input>>sId[cnt++];
        
    }
    input.close();
    
    return --cnt;
}

int random(int n){
    return rand()%n;
}