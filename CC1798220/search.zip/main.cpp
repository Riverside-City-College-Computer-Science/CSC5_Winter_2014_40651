/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Search an array using a vector
 * Created on January 29, 2014, 7:54 PM
 */


//system libraries

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <vector>
#include <ctime>

// No Global COnstants

//Function Prototypes
void filAray(int [],int);
void prntAry(int [],int,int);
int find(const int [],int,int,int);
using namespace std;



int main(int argc, char** argv) {
// declare and set up prob
const int SIZE=100;
int array[SIZE];
srand(static_cast<unsigned int>(time(0)));
//init array
filAray(array,SIZE);
//display
prntAry(array,SIZE,10);
//find a value
int val=20;
cout<<"Value found at"<<find<<(array,SIZE,val,0)<<endl;
//exit

    return 0;
}

int find(const int a[],int n,int val,int pStrt){
     for(int i=pStrt;i<n;i++){
            if (a[i]==val)return i;
}
return -1;
}

//fill the array with 2 digit numbers
void filAray(int a[],int n){
    for(int i=0;i<n;i++)(
            a[i]=rand()%90+10);
}
void prntAry(int a[],int n,int perLine){
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%10==(perLine))cout<<endl;
        
    }
}