/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * power of loops
 *
 * Created on January 15, 2014, 9:20 PM
 */
//system libraries
#include <iostream>
#include <iomanip>
#include<cmath>

using namespace std;

//Global Constants

//Function Prototypes

//Executiion begins here
int main(int argc, char** argv) {

    //declare variables
    float ex=1, x, term=1, tol=1e-6;
    //input the power of x
    cout<<"Input x found in e^x "<<endl;
    cin>>x;
    //loop and stop when tolerance is reached
    for (int i=1;term>tol;i++){
        term*=x/i;
        ex+=term;
    }
    //compare results
    cout<<"Exact result e"<<x<<(x)<<endl;
    cout<<"Approx result"<<x<<endl;
    return 0;
}

