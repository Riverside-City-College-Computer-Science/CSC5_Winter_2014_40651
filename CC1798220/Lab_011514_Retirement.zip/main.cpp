/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Retirement Calculator
 * Created on January 15, 2014, 8:30 PM
 */
//System Libraries
#include <iostream>
#include <iomanip>




using namespace std;
//Global Constants
const unsigned char CNV_PERC=100
;
//Function Prototypes

// Execution begins here
int main(int argc, char** argv) {

    //Declare Variables
    float retSave=0, salary, yrDep, iRate;
    //Input some values
    cout<<"what salary do you make $"<<endl;
    cin>>salary;
    cout<<"what percentage of your salary would you put into retirement?"<<endl;
    cin>>yrDep;
    yrDep*=(salary/CNV_PERC);
    cout<<"what municipal bond rate will you use %"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    cout<<setprecision(2)<<fixed<<showpoint;
    cout<<endl;
    //Heading
    cout<<"Income during retirement must be >= salary"<<endl;
    cout<<"muni bond rate ="<<iRate<<endl;
    cout<<"Yearly deposit in $"<<yrDep<<endl;
    cout<<"required savings to retire"<<salary/iRate<<endl;
    cout<<"year and retirement savings"<<endl;
    //loop and print as you go to watch the savings grow
    int year=0;
    do{
            retSave*=(1+iRate);
            retSave+=yrDep;
            year++;
            cout<<setw(4)<<year;
            cout<<setw(15)<<retSave<<endl;
    }while(retSave<salary/iRate);
    
    return 0;
}

