/* 
 * File:   main.cpp
 * Author: Zachery Ludwin
 * Created on January 6, 2014, 6:13 PM
 * Our first program in Netbeans
/

#include <iostream>

using namespace std;

 * Global Constants
  
 * Function Prototypes
 
 * Execution begins here/
int main(int argc, char** argv) {
/print the string hello world
Output<<"Hello_World"<<endl;
    return 0;
}

