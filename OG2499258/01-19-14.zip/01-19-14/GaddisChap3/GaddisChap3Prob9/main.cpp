/*  * File:   main.cpp
 * Author: Oscar
 *GaddisChap3Prob9
 * Created on January 17, 2014, 6:46 PM
 */

#include <cmath>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int Widgets=9.2, Pallet, Swidgets;
    cout<<"How much does a Pallet weigh?"<<endl;
    cin>>Pallet;
    //compute the weight
    Swidgets= Pallet * Widgets;
    cout<<"The total weight of the Pallet stacked with Widgets is "<<Swidgets<<endl;
    return 0;
}

