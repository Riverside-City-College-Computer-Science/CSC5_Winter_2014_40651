/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *GaddisChap3Prob1
 * Created on January 15, 2014, 10:49 PM
 */

#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare variables
    int Fuel, Miles, Distance;
    
    cout<<"How many gallons of gas can a car hold?"<<endl;
    cin>>Fuel;
    cout<<"How many miles can be driven on a full tank?"<<endl;
    cin>>Distance;
    //compute and display the Gas and tMiles
    Miles=Distance / Fuel ;
    cout<<"The number of Miles per gallon is "<<Miles<<endl;
    return 0;
}

