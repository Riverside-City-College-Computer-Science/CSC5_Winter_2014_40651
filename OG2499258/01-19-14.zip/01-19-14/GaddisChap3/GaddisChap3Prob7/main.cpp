/* 
 * File:   main.cpp
 * Author: Oscar
 *GaddisChap3Prob7
 * Created on January 19, 2014, 2:52 PM
 */

#include <iostream> 
 using namespace std; 

 int main () { 
 
 string mon1, mon2, mon3; 
 float  rain1, rain2, rain3; 
 cout << "Please enter month 1:"<<endl; 
 cin >> mon1; 
 cout << "Please enter rainfall:"<<endl; 
 cin >> rain1; 

 cout << "Please enter month 2:"<<endl; 
 cin >> mon2; 
 cout << "Please enter rainfall:"<<endl; 
 cin >> rain2; 

 cout << "Please enter month 3:"<<endl; 
 cin >> mon3; 
 cout << "Please enter rainfall:"<<endl; 
 cin >> rain3; 

 string months = mon1 + ", " + mon2 + ", & " + mon3; 
 float average = (rain1+rain2+rain3)/3.0; 
 cout << "The average monthly rainfall for " << months << " is " << average <<endl; 

 return 0; 
 } 

