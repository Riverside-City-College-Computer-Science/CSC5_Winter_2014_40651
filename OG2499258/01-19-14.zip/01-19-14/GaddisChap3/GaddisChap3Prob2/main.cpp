/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 * GaddisChap3Prob2
 * Created on January 19, 2014, 3:29 PM
 */

#include <cstdlib>
#include<iostream>
#include <iomanip>
using namespace std;

int main(){

 float classA = 15, classB = 12, classC = 9;

 float numberA, numberB, numberC;

 float total;

 cout<<"How many tickets were sold for Class A? "<<endl;
 cin>>numberA;

 cout<<"How many tickets were sold for Class B? "<<endl;
 cin>>numberB;

 cout<<"How many tickets were sold for Class C? "<<endl;
 cin>>numberC;

 
 cout<< setprecision(2) << fixed <<endl;

 cout<<"Sales from Class A: $"<< numberA * classA<<endl;

 cout <<"Sales from Class B: $"<< numberB * classB<<endl;

 cout<<"Sales from Class C: $"<< numberC * classC<<endl;

 total = (numberA*classA) + (numberB*classB) + (numberC*classC);
 cout<<"Total sales generated: $"<< total << endl << endl;

return 0;

}
