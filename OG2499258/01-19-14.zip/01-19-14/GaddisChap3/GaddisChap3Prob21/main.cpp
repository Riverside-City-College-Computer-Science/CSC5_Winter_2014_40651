/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 3:44 PM
 */

#include <cstdlib>
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

int main() {
 float angle, sine, cosine, tangent;
 
 cout<<"Angle Calculator"<<endl;
 
 cout<<"Enter an angle (in radians): "<<endl;
 cin>>angle;

 sine = sin(angle);
 cosine = cos(angle);
 tangent = tan(angle);

 cout<<setprecision(4)<< fixed<<endl;

 cout<<"The sine is: "<< sine <<endl;

 cout<<"The cosine is: "<< cosine <<endl;

 cout<<"The tangent is: "<< tangent << "\n\n"<<endl;

 return 0;

}