/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *GaddisChap3Prob10
 * Created on January 17, 2014, 2:10 PM
 */
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
     float Ecookies=4, SCals=75, tCals = Ecookies * SCals;
    cout<<"How many cookies were eaten?"<<endl;
    cin>>Ecookies;
    //compute and display the number of tCals consumed
    tCals=Ecookies * SCals ;
    cout<<"The tCals consumed is? "<<tCals<<endl;
            
    return 0;
}

