/* 
 * File:   main.cpp
 * Author: Oscar
 *GaddisChap3Prob12
 * Created on January 19, 2014, 4:40 PM
 */

#include <cstdlib>
#include<iostream>
#include<iomanip>

using namespace std;
int main() {

 const float YEN_PER_DOLLAR = 83.14;

 const float EUROS_PER_DOLLAR = 0.7337;

 float dollars, yen, euros;

 cout << setprecision(2) << fixed;

 cout << "Enter dollar amount: "<<endl;

 cin >> dollars;

 yen = dollars * YEN_PER_DOLLAR;

 euros = dollars * EUROS_PER_DOLLAR;

 cout<<"Conversion"<<endl;

 cout<< "$" << dollars << " = " << yen << " Yen "<<endl;

 cout<< "$" << dollars << " = " << euros << " Euros "<<endl;

 return 0;

}

