/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 3:54 PM
 */

#include <cstdlib>
#include<iostream>

#include<iomanip>
using namespace std;
int main()
{

 float propertyValue, assessmentValue, propertyTax, quaterlyPayment;


 cout<<"  Senior citizens homeowner exemption "<<endl;
 cout<<"Enter the actual value of the property: "<<endl;
 cin>>propertyValue;
 
 assessmentValue = propertyValue * 0.60;

 propertyTax = ((assessmentValue - 5000) / 100) * 2.64;  //don't forget to include the 5k senior exemption

 quaterlyPayment = propertyTax/4;


 cout<<setprecision(2) << fixed;

 cout<<"You will pay: $" << propertyTax << " annual property tax "<<endl;

 cout<<"Your quarterly payments will be: $" << quaterlyPayment <<endl;


 return 0;

}