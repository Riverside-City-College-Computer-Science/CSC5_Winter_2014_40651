/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *GaddisChap3Prob3
 * Created on January 18, 2014, 12:16 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int rent, utilities, phone, cable, Tpay;
    //Monthly rent
    cout<<"how much rent is paid monthly ?"<<endl;
    cin>>rent;
    //monthly utilities
    cout<<"monthly utilities rent ?"<<endl;
    cin>>utilities;
    //monthly phones
    cout<<"monthly phone bill ?"<<endl;
    cin>>phone;
    //monthly cable
    cout<<"monthly cable bill ?"<<endl;
    cin>>cable;
    Tpay=rent + utilities + phone + cable;
    cout<<"The monthly Tpay is "<<Tpay<<endl;
    

    return 0;
}


