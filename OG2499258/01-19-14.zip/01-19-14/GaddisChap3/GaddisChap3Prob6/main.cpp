/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *GaddisChap3Prob6
 * Created on January 18, 2014, 5:13 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float Average, Test1, Test2, Test3, Test4, Test5;
    
    cout<<"What are your Test1 scores ?"<<endl;
    cin>>Test1;
    cout<<"What are your Test2 scores ?"<<endl;
    cin>>Test2;
    cout<<"What are your Test3 scores ?"<<endl;
    cin>>Test3;
    cout<<"What are your Test4 scores ?"<<endl;
    cin>>Test4;
    cout<<"What are your Test5 scores ?"<<endl;
    cin>>Test5;
     Average=Test1+Test2+Test3+Test4+Test5;
     
     
     
    cout<<"what is the Average score ?"<<Average/5<<endl;
    
      return 0;
}

