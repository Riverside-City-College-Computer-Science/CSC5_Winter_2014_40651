/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 15, 2014, 7:14 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

//Global Constant
const short CNV_PERC=100;

//Function Prototype 

//Execution Begins Here!

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variable
    float presVal, fchrVal, iRate;
    short nPeriods;
    //Prompt for inputs
    cout<<"What is your present value $!s"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    cout<<"How many compounding peiods? (yrs)"<<endl;
    cin>>nPeriods;
    //loop to determine the future value
    //Print every year
    fchrVal=presVal;//At time = 0
    for(int year=1;year<=nPeriods;year++) {
            fchrVal*=(1+iRate);
            cout<<setw(4)<<year;
            cout<<setw(11)<<fchrVal<<endl;
    }
    return 0;
}

