/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *
 * Created on January 15, 2014, 8:35 PM
 */

#include <iomanip>
#include <iostream>
using namespace std;


//Global constants
const unsigned char CNV_PERC=100;

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variable
    float retSave=0,salary,yrDep,iRate;
    //Input some values
    cout<<"What salary do you make$ 's"<<endl;
    cin>>salary;
    cout<<"What percentage of your salary would "
        <<"you put into retirement? $"<<endl;
    cin>>yrDep;
    yrDep*=(salary/CNV_PERC);
    cout<<"what municipal bond rate will you use $"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    //Heading
    cout<<setprecision(2)<<fixed<<showpoint<<
    cout<<endl;
    cout<<"Income in retirement >= $"<<salary<<endl;
    cout<<"Municipal bond rate = "<<iRate<<endl;
    cout<<"Yearly Deposit = $"<<yrDep<<endl;
    cout<<"Required Savings to Retirement = $"<<salary/iRate<<endl;
    cout<<"Year Retirement Savings"<<endl;
    //Loop and print as you go to watch the savings grow
    int year=0;
    do{
      retSave*=(1+iRate);
      retSave+=yrDep;
      year++;
      cout<<setw(4)<<year;
      cout<<setw(15)<<retSave<<endl;
      }while(retSave<salary/iRate);
    //Exit stage right
    return 0;
}



