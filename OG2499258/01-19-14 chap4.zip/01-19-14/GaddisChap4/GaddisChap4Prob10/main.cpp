/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 2:43 AM
 */

#include<iostream>
 using namespace std;

 //Main function
 int main()
 {
 //Variable declarations
 int beginningbalance,checks;
 double total,bankservicefees;
 
 //inputting checks
 cout<<"Enter number of checks written on this month"<<endl;
 cin>>checks;

 if(checks <0)
 {
 cout<<"Account Overdrawn"<<endl;
 }
 if(checks<20 && beginningbalance > 400)
 {
 total = checks*0.10;
 bankservicefees = (10+total);
 cout<<"Total bank service fees for the month is $"<<bankservicefees<<endl;
 }
 if(checks<20 && beginningbalance < 400)
 {
 total = checks*0.10;
 bankservicefees = (10+total+15);
 cout<<"Total bank service fees for the month is $"<<bankservicefees<<endl;
 }


 if(checks >= 20 && checks <=39)
 {
 if(beginningbalance > 400)
 {
 total = checks*0.08;
 bankservicefees = (10+total);
 cout<<"Total bank service fees for the month is $" <<bankservicefees<<endl;
 }
 }

 if(checks >= 20 && checks <=39)
 {
 if(beginningbalance < 400)
 {
 total = checks*0.08;
 bankservicefees = (10+total+15);
 cout<<"Total bank service fees for the month is $" <<bankservicefees<<endl;
 }
 }
 if(checks >= 40 && checks <=59)
 {
 if(beginningbalance > 400)
 {
 total = checks*0.06;
 bankservicefees = (10+total);
 cout<<"Total bank service fees for the month is $" <<bankservicefees<<endl;
 }
 }
 if(checks >= 40 && checks <=59)
 {
 if(beginningbalance < 400)
 {
 total = checks*0.06;
 bankservicefees = (10+total+15);
 cout<<"Total bank service fees for the month is $" <<bankservicefees<<endl;
 }
 }
 if(checks >= 60 && beginningbalance > 400)
 {
 total = checks*0.04;
 bankservicefees = (10+total);
 cout<<"Total bank service fees for the month is $" <<bankservicefees<<endl;
 }

 if(checks >= 60 && beginningbalance < 400)
 {
 total = checks*0.04;
 bankservicefees = (10+total+15);
 cout<<"Total bank service fees for the month is $"<<bankservicefees<<endl;
 }
 //pause system for a while
 return 0;
 
 }//End main function