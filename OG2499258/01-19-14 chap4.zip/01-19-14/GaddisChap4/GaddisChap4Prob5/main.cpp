/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 2:11 AM
 */

#include <iostream>
using namespace std;
int main()

{

int booksPurchased, pointsEarned;

	//If customer purchases 0 books, then he or she earns 0 points
	//If customer purchases 1 book, then he or she earns 5 points
	//If customer purchases 2 books, then he or she earns 15 points
	//If customer purchases 3 books, then he or she earns 30 points
	//If customer purchases 4 or more books, then he or she earns 60 points

cout<< "How many books were purchased? "<<endl; 	               
	cin>> booksPurchased;		                                               				                     

if  (booksPurchased < 1)
	pointsEarned = 0;
else if  (booksPurchased = 1)
	pointsEarned = 5;
else if  (booksPurchased = 2)
	pointsEarned = 15;
else if  (booksPurchased = 3)
	pointsEarned = 30; 
else     (booksPurchased >= 4)
	; pointsEarned = 60 ;

// point receive for every purchase
	cout << " the number of points awarded is:"<<  pointsEarned << "pointsEarned" <<endl;
return 0;

}
