/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 12:45 PM
 */

#include <iostream>
#include <sstream>
#include <ios>

int main (void) {
    using namespace std;
    
    int number = -1;
    cout<<"Enter a number between 1 and 10 and i will display "
            "its Roman numeral equivalent."<<endl;
    cin>>number;
    
   ostringstream oss ( "Roman numeral: ", ios_base::ate );
    switch (number)
    {
        case 1:
            oss << "I";
        case 2:
            oss << "II";
        case 3:
            oss << "III";
            break;
        case 4:
            oss << "I";
        case 5:
            oss << "V";
            break;
        case 6:
            oss << "VI";
            break;
        case 7:
            oss << "VII";
            break;
        case 8:
            oss << "VIII";
            break;
        case 9:
            oss << "I";
        case 10:
            oss << "X";
            break;
        default:
            cout << "Error!\nYou did not enter a number between 1 and 10";
            return -1;
    }

    cout << oss.str() << endl;

    return 0;
}

