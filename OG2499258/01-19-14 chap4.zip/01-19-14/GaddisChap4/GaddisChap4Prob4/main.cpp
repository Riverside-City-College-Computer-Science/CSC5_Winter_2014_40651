/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 1:00 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    float width1, width2, length1, length2, rect1, rect2;
    
    cout<<"Enter inches width of first rectangle: "<<endl;
    cin>>width1;
    cout<<"Enter inches length of first rectangle: "<<endl;
    cin>>length1;
    cout<<"Enter incheswidth of second rectangle: "<<endl;
    cin>>width2;
    cout<<"Enter inches length of second rectangle: "<<endl;
    cin>>length2;
    
    rect1 = width1 * length1;
    rect2 = width2 * length2;
    
    if (rect1 > rect2) {
        cout<<"Rectangle 2 ("<<rect2<<") is" << rect2-
                rect1
                <<"area inches larger than rectangle 1 "
                "("<< rect1 << ") ." <<endl;
    }
     else if (rect1 < rect2)
    {
      cout << "Rectangle 2 (" << rect2 << ") is " << rect2 - rect1
       << " area inches larger than rectangle 1 ("
       << rect1 << ")." << endl;
    }
    else if (rect1 == rect2)
    {
        cout <<"Rectangles 1 and 2 are equal at"<< rect1 << 
                " area inches. "<<endl;
        
    return 0;
    }
}