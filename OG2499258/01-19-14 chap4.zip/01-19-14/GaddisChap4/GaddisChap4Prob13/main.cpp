/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 19, 2014, 2:00 AM
 */
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

int main()
{
	char name[40];
	double vault1, vault2, vault3;
	char date1[40], date2[40], date3[40];
	// Name of pole vaulter
	cout << "What is the name of the pole vaulter? " << endl;
	cin.getline(name,40);
	// Month1, Vault1
	cout << "What was the month of the first pole vault? " << endl;
	cin.getline(date1,40);
	cout << "What was the height of the first pole vault? " << endl;
	cin >> vault1 ;

	// Month2, Vault2
	cout << "What was the month of the second pole vault? " << endl;
	cin.getline(date2,40);
	cout << "What was the height of the second pole vault? " << endl;
	cin >> vault2;

	// Month3, Vault3
	cout << "What was the month of the third pole vault? " << endl;
	cin.getline(date3,40);
	cout << "What was the height of the third pole vault? " << endl;
	cin >> vault3;
	return 0;
}

