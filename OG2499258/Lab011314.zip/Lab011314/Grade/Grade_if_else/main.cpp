/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *
 * Created on January 13, 2014, 8:52 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!


/*
 * 
 */
int main(int argc, char** argv) {
    //Declare our verification
    short score;
    char grade;
    //Input the score
    cout<<"What is your test/project/hmwk score?"<<endl*;
    cin>>score;
    //Process the grade
    if(score>=90)  grade='A';
    else if (score>=80)grade='B';
    else if (score>=70)grade='C';
    else if (score>=60)grade='D';
    else               grade='F';
    //output the grade
    cout<<"Your grade is a "<<grade<<endl*;
    //Exit stage right
    return 0;
}

