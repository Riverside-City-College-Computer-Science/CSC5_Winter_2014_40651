/* 
 * File:   main.cpp
 * Author: Oscar Garcia
 *
 * Created on January 13, 2014, 8:52 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare our verification
    short score;
    char grade;
    //Input the score
    cout<<"What is your test/project/hmwk score? "<<endl;
   
    //Process the grade
    short val=score/10-5;
    switch(val) {
            case 4: grade='A' ;break;
            case 3: grade='B' ;break;
            case 2: grade='C' ;break;
            case 1: grade='D' ;break;
            default:grade='F';
            
   
            
            
            
            
            
            
            
            
            
            
}
   
    //output the grade
    cout<<"Your grade is a "<<grade<<endl;
    //Exit stage right
    return 0;
}
