/* 
 * File:   main.cpp
 * Author: Oscar
 *
 * Created on January 29, 2014, 7:58 PM
 */

#include <cstdlib>
#include <vector>
#include <iostream>
#include <ctime>
using namespace std;

//Global Constants

//Function Prototypes
//Function Prototypes

void filAray(int [],int);

void prntAry(const int [],int,int);
void prntVec(vector<int>&,int);
int find(const int[],int,int,int);
void find(const int[],int,int, vector<int> &);


int main(int argc, char** argv) {

//Declare and setup the problem

const int SIZE=100;

int array[SIZE];

srand (static_cast<unsigned int>(time(0)));

//Initialize the array

filAray(array,SIZE);

//Display the array

prntAry(array, SIZE,10);

//find a value

int val=20,pos=-1;

do{

  

    pos=find(array,SIZE,val,pos+1);

cout<<"Value fount at "<<pos<<endl;

}while(pos>0);
//declare
vector<int> posVec;
find(array,SIZE,val,posVec);
posVec.push_back(pos);


//print out the vector
prntVec(posVec,10);

for(int i=0;i<posVec.size();i++){

    cout<<"value fount at "<<posVec[i]<<endl;

}

//Exit stage right

    return 0;

}
void printVec(vector<int>&vec,int perLine){

 cout<<endl;
 cout<<"Position Vector = ("<<endl;
 for(int i=0;i<vec.size();i++){
 cout<<vec[i]<<" ";
 if(i%10==(perLine-1))cout<<endl;

        

    }

    cout<<endl;

}

void find(const int a[],int val,int n,vector<int> &vec){
    for (int i=0;i<n;i++){
    if(a[i]==val)vec.push_back(i);
    }
}





int find(const int a[],int n,int val,int pStrt){

    for(int i=pStrt;i<n;i++){

        if(a[i]==val)return i;

        

    }

    return -1;

}







//Fill the array with 2 digit numbers

void filAray(int a[],int n){

    for(int i=0;i<n;i++){

        a[i]=rand()%90+10;

    }

}




void prntAry(const int a[],int n,int perLine){

    cout<<endl;

    for(int i=0;i<n;i++){

        cout<<a[i]<<" ";

        if(i%10==(perLine-1))cout<<endl;

        

    }

    cout<<endl;

}