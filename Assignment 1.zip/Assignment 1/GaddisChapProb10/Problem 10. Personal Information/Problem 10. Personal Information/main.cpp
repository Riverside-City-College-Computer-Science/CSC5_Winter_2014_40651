//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 10. Personal Information
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    cout << "Jonathan Gaitan\n" "14334 Upas Ct, Fontana CA 92335\n" "909 770 3133\n" "Computer Programming\n";
    
    return 0;
}

