//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 4. Restaurant bill
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    float mealCost;
    float totalCost;
    float aTax;
    float aTip;
    float mWtax;
    float tax = 0.0675;
    float tip = .15;
    
    cout<< "How much was your bill before taxes?" <<endl;
    cin>> mealCost;
    
    //total amount of meal with tax of .0675
    aTax = (mealCost)*(tax);
    
    //total amount of meal after tax
    mWtax = (aTax) + (mealCost);
    
    //total tip with meal after tax
    aTip = (mWtax) * (tip);
    
    //the total amount after taxes and tip included
    totalCost = (mWtax) + (aTip);
    
    
    cout<< "The amount of the meal came out to $" <<mealCost<<endl;
    cout<< "With a sales tax of 6.75 percent the tax was $" <<aTax <<endl;
    cout<< "With a tip of 15 percent the tip came out to $" <<aTip <<endl;
    cout<< "After taxes and tip the total amount of the meal was $" <<totalCost<<endl;

    return 0;
}

