//
//  main.cpp
//  book:: Gaddis
//  chapter:: 1
//  Problem 7. Distance per gas tank
//
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    float mpgTown;
    float mpgHw;
    float aTown;
    float aHw;
    int gTank;
    
    //gas tanks capacity
    cout<< "How big is the cars gas tank?\n";
    cin>>gTank;
    
    //Average mpg
    cout<< "About how many miles per gallon do you get in town?\n";
    cin>>mpgTown;
    
    cout<< "About how many miles per gallon do you get on the highway?\n";
    cin>>mpgHw;
    
    //calculate miles traveled by multiplying miles per gallong to gas tank
    aTown = (gTank)*(mpgTown);
    aHw =   (gTank)*(mpgHw);
    
    cout<< "MPG in Town " << aTown <<"\n";
    cout<< "MPG on Highway " <<aHw <<"\n";
    return 0;
}

