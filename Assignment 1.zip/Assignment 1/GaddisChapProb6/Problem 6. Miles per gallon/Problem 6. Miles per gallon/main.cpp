//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 6. Miles per gallon
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int miles, gallons, mpg;

int main()
{
    // Imput amount of miles on a full tank traveld before refueling
    cout <<" How many miles on a full tank did you travel?\n";
    cin >>miles;
    
    // How many gallons does the car hold?
    cout << "How many gallons is the car?\n";
    cin >>gallons;
    
    //Process - calculated mpg by dividing miles travled by tank capacity
    mpg = miles / gallons;
    
    cout << mpg <<"\n";
    
    return 0;
}

