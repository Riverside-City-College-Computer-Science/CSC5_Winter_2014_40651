//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 5. Cyborg data type size
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    cout<< "These are the amounts of memory used by each type.\n";
    cout<< " The size of a char is " <<sizeof(char);
    cout<< " bytes.\n";
    cout<< " The size of a integer is " <<sizeof(int);
    cout<< " bytes.\n";
    cout<< " The size of a float is " <<sizeof(float);
    cout<< " bytes.\n";
    cout<< " The size of a double is " <<sizeof(double);
    cout<< " bytes.\n";
    
    
    
    return 0;
}

