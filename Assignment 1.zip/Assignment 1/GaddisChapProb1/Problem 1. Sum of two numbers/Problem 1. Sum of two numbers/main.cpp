//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 1. Sum of two numbers
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;


int main()
{
    int numberOne, numberTwo, total;
    numberOne = 62;
    numberTwo = 99;
    total = (numberOne)+(numberTwo);
    
    // The sum of 61 + 99 is equal to 161
    cout << numberOne << "+" << numberTwo << "=" << total << "\n";
    return 0;
}

