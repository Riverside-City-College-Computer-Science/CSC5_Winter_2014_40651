//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 3. Sales tax
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    float totalTax;
    float stateTax = 0.04;
    float countyTax = 0.02;
    float purchase;
    cout<< "How much was your purchase?" <<endl;
    cin >> purchase;
    
    //adding the state and county tax
    totalTax = (stateTax + countyTax)* purchase;
    
    cout<< "Your purchase is $" <<purchase <<endl;
    cout<< "State tax of 4 percent" <<endl;
    cout<< "County tax of 2 percent" <<endl;
    cout<< "With a total tax of $"<<totalTax<< endl;
    

   
    return 0;
}

