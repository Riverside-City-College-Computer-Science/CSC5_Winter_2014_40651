//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//Problem 12. Diamond Pattern
//
//  Created by Jonathan Gaitan on 1/9/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    cout <<"            *   \n";
    cout <<"           ***  \n";
    cout <<"          ***** \n";
    cout <<"         ******* \n";
    cout <<"          *****  \n";
    cout <<"           ***   \n";
    cout <<"            *   \n";   
    return 0;
}

