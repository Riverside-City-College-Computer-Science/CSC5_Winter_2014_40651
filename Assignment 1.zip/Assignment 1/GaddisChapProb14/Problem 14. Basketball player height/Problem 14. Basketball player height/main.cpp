//
//  main.cpp
//  book:: Gaddis
//  chapter: 1
//  Problem 14. Basketball player height
//
//  Created by Jonathan Gaitan on 1/10/14.
//  Copyright (c) 2014 Jonathan Gaitan. All rights reserved.
//

#include <iostream>
using namespace std;




int main()
{
    int answer;
    int feet = answer / 12; // inches divided by 12 inches which is one foot
    int inches = answer % 12; // cuz its the remander of divided by 12 inches
    
    

    
    
    cout<< "What is your height in inches?\n";
    cin>> answer;
    
    //convert total inches to feet /  inches
    feet = (answer) / 12;
    inches = (answer) % (12);
    
    cout<<" You are " <<feet << "'" <<inches << "\n";
   
     

    
    

    return 0;
}

