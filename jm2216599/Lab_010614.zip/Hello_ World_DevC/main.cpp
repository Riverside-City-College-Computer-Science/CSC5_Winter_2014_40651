/*
  Jesus Mata
  January 6, 2014
  First Program in DevC
*/
  
//System Libraries
#include <cstdlib>
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char *argv[]){
    //Print Hello World
    cout<<"Hello World"<<endl;
    //Exit Stage Right
    system("PAUSE");
    return EXIT_SUCCESS;
}
