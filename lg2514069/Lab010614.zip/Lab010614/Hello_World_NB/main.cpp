/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Created on January 6, 2014, 6:13 PM
 * Our first program in netbeans!
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants


//Function Prototypes 

//Exectuion Begins Here!
int main(int argc, char** argv) {
    //Print the string Hello World
    cout<<"Hello World"<<endl;
    //Exit stage right
    return 0;
}

