/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 6, 2014, 6:13 PM
 * Our first program in netbeans
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
//Print the strings Hello World
    cout<<"Hello World"<<endl;
    //Exit stage right
    return 0;
}

