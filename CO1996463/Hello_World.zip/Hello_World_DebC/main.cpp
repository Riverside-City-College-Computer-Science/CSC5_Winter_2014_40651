/*
  Cynthia R. Olivas
  January 6th, 2014
  First Program in DevC
*/

//System Libraries
#include <cstdlib>
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins here
int main(int argc, char *argv[]){
    //Print Hello World
    cout<<"Hello World"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
