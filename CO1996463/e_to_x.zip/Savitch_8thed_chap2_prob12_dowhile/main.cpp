/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 15, 2014, 7:49 PM
 * Savitch Chapter 2 Problem 12 - Lab 01/15/14 - 40651
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float x,r,nguess, oguess;
    //Input the value to find the sq root of
    cout<<"What number do you wish to find the "
        <<"Square Root of ?"<<endl;
    cin>>x;
    //First approximation and keep count
    nguess=oguess=x/2;
    int count=0;
    do{
        oguess=nguess;
        r=x/oguess;
        nguess=(oguess+r)/2;
        count++;
    }while(nguess - oguess);
    //Output the approximation
    cout<<"The Approximation = "<<nguess<<endl;
    cout<<"It took "<<count<<" iteration for the solution"<<endl;
    //Output the actual answer
    cout<<"Exact answer = "<<sqrt(x)<<endl;
    //Exit Stage Right
    return 0;
}
