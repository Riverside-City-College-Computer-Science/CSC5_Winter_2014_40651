/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 15, 2014, 8:35 PM
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global constants
const unsigned char CNV_PERC=100;

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare
    float retSave=0, salary, yrDep, iRate;
    //input values
    cout<<"What salary do you make $'s"<<endl;
    cin>>salary;
    cout<<"What percentage of your salary would"
        <<" you put into retirement? %"<<endl;
    cin>>yrDep;
    yrDep*=(salary/CNV_PERC);
    cout<<"What municipal bond rate will you use %"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    //heading
    cout<<setprecision(2)<<fixed <<showpoint;
    cout<<endl;
    cout<<"Income during retirement >= $"<<salary<<endl;
    cout<<"Municipal bond rate = "<<iRate<<endl;
    cout<<"Yearly deposit = $"<<yrDep<<endl;
    cout<<"Required savings to retire = $"<<(salary/iRate)<<endl;
    cout<<"Year retirement savings"<<endl;
    //Loop and print as you go to watch the savings go
    int year=0;
    do{
        retSave*=(1+iRate);
        retSave+=yrDep;
        year++;
        cout<<setw(4)<<year;
        cout<<setw(15)<<retSave<<endl;
    }while(retSave<salary/iRate);
    //Exit stage right
    return 0;
}

