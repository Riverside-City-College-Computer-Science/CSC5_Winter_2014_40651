/* 
 * File:   main.cpp
 * Author: Cynthia R. Olivas
 * Created on January 15, 2014, 7:41 PM
 * Lab 01/15/14 future value with do while
 */

//System libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global constants
const short CNV_PERC=100;

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float presVal, fchrVal, iRate;
    short nPeriods;
    //Prompt for inputs
    cout<<"What is your present value $'s"<<endl;
    cin>>presVal;
    cout<<"What is your inf/inv/roi %"<<endl;
    cin>>iRate;
    iRate/=CNV_PERC;
    cout<<"How many compounding periods? (yrs)"<<endl;
    cin>>nPeriods;
    //Setup the heading
    cout<<"Year  Future Value"<<endl;
    cout<<setprecision(2)<<fixed<<showpoint;
    //Loop to determine the future value
    //Print every year
    fchrVal=presVal;//At time = 0
    int year=1;
    do {
        fchrVal*=(1+iRate);
        cout<<setw(4)<<year;
        cout<<setw(11)<<fchrVal<<endl;
        year++;
    }while(year<=nPeriods);
    //Exit stage right
    return 0;
}

